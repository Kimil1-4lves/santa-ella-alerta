import {config} from "./config.js";
const base=`https://graph.facebook.com/${config.apiVersion}`;
export async function sendWhatsAppText(to,body){const r=await fetch(`${base}/${config.phoneNumberId}/messages`,{method:"POST",headers:{Authorization:`Bearer ${config.accessToken}`,"Content-Type":"application/json"},body:JSON.stringify({messaging_product:"whatsapp",to,type:"text",text:{body,preview_url:false}})});const data=await r.json();if(!r.ok)throw new Error(`WhatsApp API: ${JSON.stringify(data)}`);return data;}
