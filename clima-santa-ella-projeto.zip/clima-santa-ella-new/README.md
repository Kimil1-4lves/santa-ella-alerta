# Clima Santa Ella — Bot de WhatsApp

Bot de WhatsApp para consultar o tempo da região de Santa Ella, Araçariguama (SP), usando Open-Meteo e WhatsApp Cloud API.

Comandos: `oi`, `menu`, `ajuda`, `agora`, `hoje`, `amanhã`, `chuva`, `sol`.

Nunca publique um `.env` com tokens ou senhas. Use as variáveis de ambiente da hospedagem.
